/**
 * Load all devices from the database using the database
 * The result is saved to res.locals.device
 */
 var requireOption = require('../requireOption');

 module.exports = function (objectrepository) {
     return function (req, res, next) {
         next();
     };
 };