const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/I44GCB');

module.exports = mongoose;